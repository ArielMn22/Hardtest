###############################################
                Como instalar
###############################################
1. Esteja logado como ROOT.
2. Tenha conexão com a internet.
3. Execute
	# bash install.sh

###############################################
               Como desinstalar
###############################################
1. Esteja logado como ROOT.
2. Execute
	# bash remove.sh


###############################################
          Como cadastrar um usuário
###############################################
1. Acesse o seu endereço IP no seu navegador de
internet.


###############################################
     Como remover um usuário ADMINISTRADOR
###############################################
1. Esteja logado como ROOT.
2. Execute
	# hardtest -d


###############################################
               Observações:
###############################################
 - Se você executar os testes em um ambiente
 virtual, vários testes podem não funcionar
 corretamente.


###############################################
                 Documentação
###############################################
 - A documentação do programa se encontra
 dentro do diretório Documentação, diretório
este que está no mesmo local desse README.txt.


###############################################
    Encontrou algum problema? - Contate-nos
###############################################
Ariel Paixao <arielpaixao10@gmail.com>
Nhat Long <nlong0920@gmail.com>
Kamila Freitas <freitaskamila43@gmail.com>
Lucas Venâncio <lucas209.coutinho@gmail.com>
Arthur Chagas <arthurchgs@gmail.com>
