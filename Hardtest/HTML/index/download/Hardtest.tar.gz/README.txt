###############################################
                Como instalar
###############################################
1. Esteja logado como ROOT.
2. Tenha conexão com a internet.
3. Execute
	# bash install.sh

###############################################
               Como desinstalar
###############################################
1. Esteja logado como ROOT.
2. Execute
	# bash remove.sh

*OBS: Para reinstalar o programa execute:
	# bash reinstall.sh
	
	
###############################################
          Como cadastrar um usuário
###############################################
1. Acesse o seu endereço IP no seu navegador de
internet.


###############################################
     Como remover um usuário ADMINISTRADOR
###############################################
1. Esteja logado como ROOT.
2. Execute
	# hardtest -d


###############################################
               Observações:
###############################################
 - Se você executar os testes em um ambiente
 virtual, vários testes podem não funcionar
 corretamente.
 - Encontre os arquivos .log no diretório:
 "/var/log/Hardtest"


###############################################
                 Documentação
###############################################
 - A documentação do programa se encontra
 dentro do diretório Documentação, diretório
este que está no mesmo local desse README.txt.

- Documentação: Gerenciamento do programa (passo 
a passo de como executar o programa).

- Documentação sobre o programa  (Objetivo,
Missão, Visão e Valores).

- Documentação: Perguntas & Respostas.


###############################################
    Encontrou algum problema? - Contate-nos
###############################################
Ariel Paixao <arielpaixao10@gmail.com>
Nhat Long <nlong0920@gmail.com>
Kamila Freitas <freitaskamila43@gmail.com>
Lucas Venâncio <lucas209.coutinho@gmail.com>
Arthur Chagas <arthurchgs@gmail.com>
