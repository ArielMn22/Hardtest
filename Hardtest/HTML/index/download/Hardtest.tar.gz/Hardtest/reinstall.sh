#!/bin/bash

bash remove.sh
echo yes | bash install.sh
