###############################################
                Como instalar
###############################################
1. Esteja logado como ROOT.
2. Tenha conexão com a internet.
3. Execute
	# bash install.sh

###############################################
               Como desinstalar
###############################################
1. Esteja logado como ROOT.
2. Execute
	# bash remove.sh

###############################################
     Como remover um usuário ADMINISTRADOR
###############################################
1. Esteja logado como ROOT.
2. Execute
	# hardtest -d

###############################################
    Encontrou algum problema? - Contate-nos
###############################################
Ariel Paixao <arielpaixao10@gmail.com>
Nhat Long <nlong0920@gmail.com>

